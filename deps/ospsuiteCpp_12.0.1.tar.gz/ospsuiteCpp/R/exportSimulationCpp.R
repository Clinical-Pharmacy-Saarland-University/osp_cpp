#' Export an individual simulation to C++
#'
#' @param simulation ospsuite simulation to be exported.
#' @param simulationBatchOption ospsuite SimulationBatchOption object with free parameter and molecule information.
#' @param outputName Both filename (without .cpp extension), as well as simulation identifier. Has to be valid C++ identifier and unique among multiple simulations.
#' @param outputPath Directory for C++ file output.
#'
#' @return File name if successful, NULL otherwise.
#'
#' @export
exportSimulationCpp <- function(simulation, simulationBatchOption, outputName, outputPath = getwd()) {
  batchFactory <- ospsuite:::.getNetTask("SimulationBatchFactory")
  batchSim <- batchFactory$call("Create", simulation, simulationBatchOption)
  batchSim$call("ExportToCPPCode", outputPath, FALSE, outputName)
  filename <- paste0(file.path(outputPath, outputName), ".cpp")
  if(file.exists(filename)) {
    return(filename)
  } else {
    return(NULL)
  }
}

#' Compile a simulation to a shared library
#'
#' @param filename Simulation to be compiled (.cpp)
#' @param outputPath Directory for compiled library output (.dll or .so)
#'
#' @return library name if successful, NULL otherwise.
#'
#' @export
compileSimulationCpp <- function(filename, outputPath = getwd()) {
  cppInc <- paste("-I", system.file("include", package = "ospsuiteCpp"))
  cppModel <- paste0(system.file("include", package = "ospsuiteCpp"), "/Model.cpp")
  libPath <- system.file("libs", package = "ospsuiteCpp")
  libName <- list.files(path = libPath, pattern = "ospsuite.*", recursive = TRUE, full.names = TRUE)
  cppLib <- paste0("-L",libName)

  libExt <- tools::file_ext(basename(libName))
  compiledLibName <- file.path(outputPath, paste0(tools::file_path_sans_ext(basename(filename)), ".", libExt))



  if(.Platform$OS.type == "unix") {
    system(paste("gcc -fPIC -O2 -Wall  -mfpmath=sse -msse2 -Wno-unused-function -std=c++0x -Wno-narrowing", 
                 cppInc, cppLib, cppModel, filename, "-shared -o ", compiledLibName))

  } else {
    system(paste("g++ -fPIC -O2 -Wall  -mfpmath=sse -msse2 -Wno-unused-function -std=c++0x -Wno-narrowing", 
                 cppInc, cppLib, cppModel, filename, "-shared -o ", compiledLibName))
  }

  if(file.exists(compiledLibName)) {
    return(compiledLibName)
  } else {
    return(NULL)
  }
}
