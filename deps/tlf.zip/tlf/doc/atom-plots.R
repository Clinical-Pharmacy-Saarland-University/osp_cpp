## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  dpi = 300,
  fig.align = "center",
  out.width = "100%",
  fig.height = 6,
  fig.width = 8,
  fig.showtext = TRUE
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----load-data, echo=FALSE----------------------------------------------------
cosData <- data.frame(time = seq(0, 20, 0.5), cos = cos(seq(0, 20, 0.5)), sin = sin(seq(0, 20, 0.5)))
testData <- read.csv(system.file("extdata", "test-data.csv", package = "tlf"), stringsAsFactors = FALSE)

## ----initializePlot minimal example-------------------------------------------
initializePlot()

## ----initializePlot with plot configuration-----------------------------------
# Create a PlotConfiguration object to specify plot properties (here labels)
myConfiguration <- PlotConfiguration$new(
  title = "My empty plot",
  xlabel = "My X axis",
  ylabel = "My Y axis"
)
# Use the obect to define the plot properties
initializePlot(plotConfiguration = myConfiguration)

## ----show cosData, results='asis'---------------------------------------------
# data.frame for example
knitr::kable(head(cosData))

## ----show cosMetaData---------------------------------------------------------
# Define which is x and y variables using dataMapping
cosMapping <- XYGDataMapping$new(x = "time", y = "cos")

# Define the metaData
cosMetaData <- list(
  time = list(
    dimension = "Time",
    unit = "min"
  ),
  cos = list(
    dimension = "Cosinus",
    unit = ""
  )
)
cosMetaData

## ----initializePlot with smart plot configuration on metaData-----------------
# Define default Configuration with metaData
metaDataConfiguration <- PlotConfiguration$new(
  title = "Cosinus plot",
  data = cosData,
  metaData = cosMetaData,
  dataMapping = cosMapping
)

initializePlot(plotConfiguration = metaDataConfiguration)

## ----initializePlot with smart plot configuration on data---------------------
# Define default Configuration with metaData
dataConfiguration <- PlotConfiguration$new(
  title = "Cosinus plot",
  data = cosData,
  dataMapping = cosMapping
)

initializePlot(plotConfiguration = dataConfiguration)

## ----initializePlot with smart plot configuration overwritten-----------------
# Define default Configuration with metaData
overwriteConfiguration <- PlotConfiguration$new(
  title = "Cosinus plot",
  ylabel = "new y label",
  data = cosData,
  metaData = cosMetaData,
  dataMapping = cosMapping
)

initializePlot(plotConfiguration = overwriteConfiguration)

## ----addScatter data----------------------------------------------------------
addScatter(
  data = cosData,
  metaData = cosMetaData,
  dataMapping = cosMapping
)

## ----addScatter with smart plot configuration overwritten---------------------
addScatter(
  data = cosData,
  metaData = cosMetaData,
  dataMapping = cosMapping,
  plotConfiguration = overwriteConfiguration
)

## ----addScatter xy------------------------------------------------------------
addScatter(
  x = cosData$time,
  y = cosData$cos
)

## ----addScatter xy with plot configuration overwritten------------------------
addScatter(
  x = cosData$time,
  y = cosData$cos,
  plotConfiguration = overwriteConfiguration
)

## ----addScatter xy with optional properties-----------------------------------
addScatter(
  x = cosData$time,
  y = cosData$cos,
  color = "firebrick",
  shape = Shapes$triangleOpen,
  size = 3,
  caption = "open triangle"
)

## ----addScatter with plotObject-----------------------------------------------
scatterPlot <- addScatter(
  x = cosData$time,
  y = cosData$cos,
  color = "firebrick",
  shape = Shapes$triangleOpen,
  size = 3,
  caption = "open triangle",
  plotConfiguration = overwriteConfiguration
)

scatterPlot

addScatter(
  x = cosData$time,
  y = cosData$cos + 2,
  color = "black",
  shape = Shapes$invertedTriangle,
  size = 3,
  caption = "inverted triangle",
  plotObject = scatterPlot
)

## ----addLine xy---------------------------------------------------------------
addLine(
  x = cosData$time,
  y = cosData$cos
)

## ----addLine xy with optional properties--------------------------------------
addLine(
  x = cosData$time,
  y = cosData$cos,
  color = "firebrick",
  linetype = Linetypes$longdash,
  size = 1,
  caption = "line with\nlong dashes"
)

## ----addLine horizontal lines, eval=FALSE-------------------------------------
#  addLine(
#    y = c(1, 2, 3),
#    caption = "horizontal lines"
#  )

## ----addLine vertical lines, eval=FALSE---------------------------------------
#  addLine(
#    x = c(1, 2, 3),
#    caption = "vertical lines"
#  )

## ----addLine with plotObject, eval=FALSE--------------------------------------
#  scatterPlot <- addScatter(
#    x = cosData$time,
#    y = cosData$cos,
#    color = "firebrick",
#    shape = Shapes$diamond,
#    size = 3,
#    caption = "diamond",
#    plotConfiguration = overwriteConfiguration
#  )
#  
#  scatterPlot
#  
#  addLine(
#    y = 0.5,
#    color = "dodgerblue",
#    linetype = Linetypes$solid,
#    size = 0.5,
#    caption = "threshold",
#    plotObject = scatterPlot
#  )

## ----addRibbon data-----------------------------------------------------------
sinCosMapping <- RangeDataMapping$new(
  x = "time",
  ymin = "sin",
  ymax = "cos"
)

addRibbon(
  data = cosData,
  metaData = cosMetaData,
  dataMapping = sinCosMapping
)

## ----addRibbon xy-------------------------------------------------------------
addRibbon(
  x = cosData$time,
  ymin = cosData$sin,
  ymax = cosData$cos
)

## ----addRibbon optional inputs------------------------------------------------
addRibbon(
  x = cosData$time,
  ymin = cosData$sin,
  ymax = cosData$cos,
  fill = "firebrick",
  alpha = 0.5,
  caption = "ribbon plot"
)

## ----addErrorbar xy-----------------------------------------------------------
addErrorbar(
  x = cosData$time,
  ymin = cosData$sin,
  ymax = cosData$cos
)

## ----addErrorbar optional inputs----------------------------------------------
addErrorbar(
  x = cosData$time,
  ymin = cosData$sin,
  ymax = cosData$cos,
  color = "firebrick",
  linetype = Linetypes$solid,
  capSize = 5,
  size = 0.5,
  caption = "error bar plot"
)

## ----addErrorbar and Scatter--------------------------------------------------
errorPlot <- addErrorbar(
  x = cosData$time,
  ymin = cosData$cos - 0.1,
  ymax = cosData$cos + 0.2,
  caption = "error",
  color = "black",
  size = 0.5,
  plotConfiguration = overwriteConfiguration
)

errorPlot

addScatter(
  x = cosData$time,
  y = cosData$cos,
  color = "firebrick",
  shape = Shapes$diamond,
  size = 3,
  caption = "diamond",
  plotObject = errorPlot
)

