## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  dpi = 300,
  fig.align = "center",
  out.width = "100%",
  fig.height = 6,
  fig.width = 8,
  fig.showtext = TRUE
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----load-data, results='asis'------------------------------------------------
# Load example
pkRatioData <- read.csv(
  system.file("extdata", "test-data.csv", package = "tlf"),
  stringsAsFactors = FALSE
)

# pkRatioData
knitr::kable(utils::head(pkRatioData), digits = 2)

## ----load-metadata, echo=FALSE------------------------------------------------
# Load example
pkRatioMetaData <- list(
  Age = list(
    dimension = "Age",
    unit = "yrs"
  ),
  Obs = list(
    dimension = "Clearance",
    unit = "dL/h/kg"
  ),
  Pred = list(
    dimension = "Clearance",
    unit = "dL/h/kg"
  ),
  Ratio = list(
    dimension = "Ratio",
    unit = ""
  )
)

## ----show-metadata, results='asis'--------------------------------------------
knitr::kable(data.frame(
  Variable = c("Age", "Obs", "Pred", "Ratio"),
  Dimension = c("Age", "Clearance", "Clearance", "Ratio"),
  Unit = c("yrs", "dL/h/kg", "dL/h/kg", "")
))

## ----minimal-example, fig.height=5, fig.width=7.5-----------------------------
plotPKRatio(data = pkRatioData[, c("Age", "Ratio")])

## ----group-mapping------------------------------------------------------------
# Two-step process
colorMapping <- GroupMapping$new(color = "Sex")
dataMappingA <- PKRatioDataMapping$new(
  x = "Age",
  y = "Ratio",
  groupMapping = colorMapping
)

print(dataMappingA$groupMapping$color$label)

# One-step process
dataMappingB <- PKRatioDataMapping$new(
  x = "Age",
  y = "Ratio",
  color = "Sex"
)

print(dataMappingB$groupMapping$color$label)

## ----dataMappingB, fig.height=5, fig.width=7.5--------------------------------
plotPKRatio(
  data = pkRatioData,
  dataMapping = dataMappingB
)

## ----dataMapping2groups, fig.height=5, fig.width=7.5--------------------------
dataMapping2groups <- PKRatioDataMapping$new(
  x = "Age",
  y = "Ratio",
  color = "Sex",
  shape = c("Country", "AgeBin")
)
plotPKRatio(
  data = pkRatioData,
  dataMapping = dataMapping2groups
)

## ----echo=FALSE, results='asis'-----------------------------------------------
groupDataFrame <- data.frame(
  AgeBin = rep(c("Peds", "Adults"), 6),
  Country = rep(rep(c("Canada", "Germany", "France"), each = 2), 2),
  Sex = rep(c("Male", "Female"), each = 6),
  Group = paste(rep(c("Young", "Old"), 6), rep(rep(c("Canadian", "German", "French"), each = 2), 2), rep(c("Males", "Females"), each = 6))
)

knitr::kable(groupDataFrame)

## ----dataMappingDF, fig.height=5, fig.width=7.5-------------------------------
dataMappingDF <- PKRatioDataMapping$new(
  x = "Age",
  y = "Ratio",
  color = groupDataFrame,
  shape = groupDataFrame
)
plotPKRatio(
  data = pkRatioData[!(pkRatioData$Country %in% "France"), ],
  dataMapping = dataMappingDF
)

## ----linesMapping-------------------------------------------------------------
linesMapping <- PKRatioDataMapping$new()
linesMapping$lines

## ----linesMapping-plot, fig.height=5, fig.width=7.5---------------------------
linesMapping <- PKRatioDataMapping$new(
  lines = list(pkRatio1 = 1, pkRatio2 = c(0.2, 5)),
  x = "Age",
  y = "Ratio",
  color = "Sex"
)
plotPKRatio(
  data = pkRatioData,
  dataMapping = linesMapping
)

## ----results='asis'-----------------------------------------------------------
# Test of getPKRatioMeasure
PKRatioMeasure <- getPKRatioMeasure(data = pkRatioData[, c("Age", "Ratio")])

knitr::kable(
  x = PKRatioMeasure,
  caption = "Qualification of PK Ratios"
)

