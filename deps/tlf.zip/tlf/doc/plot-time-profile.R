## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  dpi = 300,
  fig.align = "center",
  out.width = "100%",
  fig.height = 6,
  fig.width = 8,
  fig.showtext = TRUE
)

## ----setup--------------------------------------------------------------------
require(tlf)
# Place default legend position above the plot for prettier time profile plots
setDefaultLegendPosition(LegendPositions$outsideTop)

## ----get simulated data for examples------------------------------------------
# Simulation time
simTime <- seq(0, 24, 0.1)

# metaData will be used during the smart mapping
# to label the axes as "dimension [unit]"
metaData <- list(
  time = list(
    dimension = "Time",
    unit = "h"
  ),
  concentration = list(
    dimension = "Concentration",
    unit = "mg/l"
  )
)
# Spread metaData to min/max
metaData$maxConcentration <- metaData$concentration
metaData$minConcentration <- metaData$concentration

# Simulated data 1: exponential decay
simData1 <- data.frame(
  time = simTime,
  concentration = 15 * exp(-0.1 * simTime),
  minConcentration = 12 * exp(-0.12 * simTime),
  maxConcentration = 18 * exp(-0.08 * simTime),
  caption = "Simulated Data 1"
)

# Simulated data 2: first order absorption with exponential decay
simData2 <- data.frame(
  time = simTime,
  concentration = 10 * exp(-0.1 * simTime) * (1 - exp(-simTime)),
  minConcentration = 8 * exp(-0.12 * simTime) * (1 - exp(-simTime)),
  maxConcentration = 12 * exp(-0.08 * simTime) * (1 - exp(-simTime)),
  caption = "Simulated Data 2"
)

## ----get observed data for examples-------------------------------------------
# Observed data 1
obsData1 <- data.frame(
  time = c(1, 3, 6, 12, 24),
  concentration = c(11.7, 8.4, 7.5, 3.6, 1.0),
  sd = c(0.204, 0.21, 0.241, 0, 0.18),
  caption = "Observed Data 1"
)

# Observed data 2
obsData2 <- data.frame(
  time = c(0, 1, 3, 6, 12, 24),
  concentration = c(0, 6.1, 7.3, 4.4, 3.2, 1.1),
  minConcentration = c(0, 5.7, 7.0, 4.3, 2.5, 0.8),
  maxConcentration = c(0, 7.1, 8.2, 5.8, 3.3, 1.11),
  caption = "Observed Data 2"
)

## ----examples single simulation-----------------------------------------------
# Define Data Mapping
simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration",
  group = "caption"
)

plotTimeProfile(
  data = simData1,
  metaData = metaData,
  dataMapping = simDataMapping
)

plotTimeProfile(
  data = simData2,
  metaData = metaData,
  dataMapping = simDataMapping
)

## ----examples single simulation with confidence interval----------------------
# Define Data Mapping
simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption"
)

plotTimeProfile(
  data = simData1,
  metaData = metaData,
  dataMapping = simDataMapping
)

plotTimeProfile(
  data = simData2,
  metaData = metaData,
  dataMapping = simDataMapping
)

## ----examples multiple simulations no caption---------------------------------
# Define Data Mapping
# Not using a group here will plot both profiles
# but as they were the same data
simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration"
)

plotTimeProfile(
  data = rbind.data.frame(
    simData1,
    simData2
  ),
  metaData = metaData,
  dataMapping = simDataMapping
)

## ----examples multiple simulations--------------------------------------------
# Define Data Mapping
# Using a group to plot both profiles

simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration",
  group = "caption"
)

plotTimeProfile(
  data = rbind.data.frame(
    simData1,
    simData2
  ),
  metaData = metaData,
  dataMapping = simDataMapping
)

## ----examples multiple simulations with confidence interval-------------------
# Define Data Mapping
# ymin and ymax define the CI
simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption"
)

plotTimeProfile(
  data = rbind.data.frame(
    simData1,
    simData2
  ),
  metaData = metaData,
  dataMapping = simDataMapping
)

## ----examples single observation----------------------------------------------
# Define Data Mapping
obsDataMapping <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  group = "caption"
)

plotTimeProfile(
  observedData = obsData1,
  metaData = metaData,
  observedDataMapping = obsDataMapping
)

plotTimeProfile(
  observedData = obsData2,
  metaData = metaData,
  observedDataMapping = obsDataMapping
)

## ----examples single observation with confidence interval as error------------
# Define Data Mapping
obsDataMapping1 <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  error = "sd",
  group = "caption"
)

plotTimeProfile(
  observedData = obsData1,
  metaData = metaData,
  observedDataMapping = obsDataMapping1
)

## ----examples single observation with confidence interval as ymin-ymax--------
# Define Data Mapping
obsDataMapping2 <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption"
)

plotTimeProfile(
  observedData = obsData2,
  metaData = metaData,
  observedDataMapping = obsDataMapping2
)

## ----examples multiple observations no caption--------------------------------
# Define Data Mapping
obsDataMapping <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  group = "caption"
)

plotTimeProfile(
  observedData = rbind.data.frame(
    obsData1[, c("time", "concentration", "caption")],
    obsData2[, c("time", "concentration", "caption")]
  ),
  metaData = metaData,
  observedDataMapping = obsDataMapping
)

## ----examples multiple observations with confidence interval------------------
# Use common variable before usinf rbind.data.frame
obsData1$minConcentration <- obsData1$concentration - obsData1$sd
obsData1$maxConcentration <- obsData1$concentration + obsData1$sd
obsData2$sd <- 0

# Define Data Mapping
obsDataMapping <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption"
)

plotTimeProfile(
  observedData = rbind.data.frame(
    obsData1,
    obsData2
  ),
  metaData = metaData,
  observedDataMapping = obsDataMapping
)

## ----examples mdv-------------------------------------------------------------
# Use common variable before usinf rbind.data.frame
mdvData <- obsData1
mdvData$mdv <- mdvData$concentration > 10

# Define Data Mapping
obsDataMapping <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption",
  mdv = "mdv"
)

plotTimeProfile(
  observedData = mdvData,
  metaData = metaData,
  observedDataMapping = obsDataMapping
)

## ----combine simulated and observed, eval= getRversion() >= "4.0"-------------
# Define Data Mappings
simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration",
  group = "caption"
)

obsDataMapping <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  group = "caption"
)

plotTimeProfile(
  data = simData1,
  observedData = obsData1,
  metaData = metaData,
  dataMapping = simDataMapping,
  observedDataMapping = obsDataMapping
)

plotTimeProfile(
  data = simData2,
  observedData = obsData2,
  metaData = metaData,
  dataMapping = simDataMapping,
  observedDataMapping = obsDataMapping
)

## ----combine simulated and observed with ci-----------------------------------
# Define Data Mappings
simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption"
)

obsDataMapping <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption"
)

plotTimeProfile(
  data = simData1,
  observedData = obsData1,
  metaData = metaData,
  dataMapping = simDataMapping,
  observedDataMapping = obsDataMapping
)

plotTimeProfile(
  data = simData2,
  observedData = obsData2,
  metaData = metaData,
  dataMapping = simDataMapping,
  observedDataMapping = obsDataMapping
)

## ----combine multiple simulated and observed----------------------------------
# Define Data Mappings
simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration",
  group = "caption"
)

obsDataMapping <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  group = "caption"
)

simAndObsTimeProfile <- plotTimeProfile(
  data = rbind.data.frame(
    simData1,
    simData2
  ),
  observedData = rbind.data.frame(
    obsData1,
    obsData2
  ),
  metaData = metaData,
  dataMapping = simDataMapping,
  observedDataMapping = obsDataMapping
)
simAndObsTimeProfile

## ----get legend properties, results='asis'------------------------------------
plotLegend <- getLegendCaption(simAndObsTimeProfile)
knitr::kable(as.data.frame(plotLegend$color))

## ----update legend properties-------------------------------------------------
plotLegend$color <- plotLegend$color[c(1, 3, 2, 4), ]
updateTimeProfileLegend(simAndObsTimeProfile, plotLegend)

## ----combine simulated and observed sharing legend----------------------------
commonSimData1 <- simData1
commonObsData1 <- obsData1
commonSimData1$caption <- "Common data 1"
commonObsData1$caption <- "Common data 1"
commonSimData2 <- simData2
commonObsData2 <- obsData2
commonSimData2$caption <- "Common data 2"
commonObsData2$caption <- "Common data 2"

plotTimeProfile(
  data = rbind.data.frame(commonSimData1, commonSimData2),
  observedData = rbind.data.frame(commonObsData1, commonObsData2),
  metaData = metaData,
  dataMapping = simDataMapping,
  observedDataMapping = obsDataMapping
)

## ----combine multiple simulated and observed with ci--------------------------
# Define Data Mappings
simDataMapping <- TimeProfileDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption"
)

obsDataMapping <- ObservedDataMapping$new(
  x = "time",
  y = "concentration",
  ymin = "minConcentration",
  ymax = "maxConcentration",
  group = "caption"
)

plotTimeProfile(
  data = rbind.data.frame(
    simData1,
    simData2
  ),
  observedData = rbind.data.frame(
    obsData1,
    obsData2
  ),
  metaData = metaData,
  dataMapping = simDataMapping,
  observedDataMapping = obsDataMapping
)

## ----time profile plot configuration------------------------------------------
tpConfiguration <- TimeProfilePlotConfiguration$new(
  data = simData1,
  metaData = metaData,
  dataMapping = simDataMapping
)

## ----define time profile plot configuration properties------------------------
# Define which lines are used for simulated data
tpConfiguration$lines$linetype <- Linetypes$solid
tpConfiguration$lines$size <- 1
tpConfiguration$lines$color <- c("blue", "red")

# Define which ribbons are used for simulated data CI
tpConfiguration$ribbons$fill <- c("dodgerblue", "firebrick")
tpConfiguration$ribbons$alpha <- 0.25

# Define which shapes are used for observed data
tpConfiguration$points$shape <- Shapes$circle
tpConfiguration$points$size <- 1
tpConfiguration$points$color <- c("blue", "red")

# Define which errorbars are used for observed data CI
tpConfiguration$errorbars$color <- "black"
tpConfiguration$errorbars$size <- 0.5

## ----time profile plot using plot configuration-------------------------------
plotTimeProfile(
  data = rbind.data.frame(
    simData1,
    simData2
  ),
  observedData = rbind.data.frame(
    obsData1,
    obsData2
  ),
  metaData = metaData,
  dataMapping = simDataMapping,
  observedDataMapping = obsDataMapping,
  plotConfiguration = tpConfiguration
)

