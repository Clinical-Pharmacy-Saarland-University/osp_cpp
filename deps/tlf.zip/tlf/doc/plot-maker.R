## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  out.width = "100%",
  include = TRUE,
  fig.align = "center",
  echo = FALSE
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----start-plot-maker---------------------------------------------------------
knitr::include_graphics("figures/plot-maker/start-plot-maker.png")

## ----import-env-data----------------------------------------------------------
knitr::include_graphics("figures/plot-maker/import-env-data.png")

## ----import-file-data---------------------------------------------------------
knitr::include_graphics("figures/plot-maker/import-file-data.png")

## ----imported-data------------------------------------------------------------
knitr::include_graphics("figures/plot-maker/imported-data.png")

## ----data-mapping-------------------------------------------------------------
knitr::include_graphics("figures/plot-maker/data-mapping.png")

## ----data-mapping-x-----------------------------------------------------------
knitr::include_graphics("figures/plot-maker/data-mapping-x.png")

## ----plot-selection-----------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-selection.png")

## ----pk-ratio-plot------------------------------------------------------------
knitr::include_graphics("figures/plot-maker/pk-ratio-plot.png")

## ----plot-labels--------------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-labels.png")

## ----plot-background----------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-background.png")

## ----plot-axes----------------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-axes.png")

## ----plot-legend--------------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-legend.png")

## ----plot-aesthetics----------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-aesthetics.png")

## ----plot-export--------------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-export.png")

## ----plot-regression----------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-regression.png")

## ----plot-tornado-------------------------------------------------------------
knitr::include_graphics("figures/plot-maker/plot-tornado.png")

