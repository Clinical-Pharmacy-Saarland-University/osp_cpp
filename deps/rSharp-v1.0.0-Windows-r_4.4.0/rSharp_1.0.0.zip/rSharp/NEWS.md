# rSharp 1.0.0

- First release of the `{rSharp}` package.

## Minor improvements and bug fixes

- github actions implementation for windows and Ubuntu R package builds.
- github actions for C# binary builds for windows and Ubuntu.

<!--
## Breaking Changes

## Major changes


-->

